// Danh sách các câu trả lời đã biết, mỗi câu có thể có nhiều đáp án đúng
const answers = {
    // Câu 6 - Điều 5: học phần tương đương có TC nhỏ hơn
    "Theo Quy chế Đào tạo, khi SV chọn học một học phần tương đương để thay thế cho một học phần yêu cầu trong Chương trình Đào tạo, nhưng học phần tương đương đó lại có số tín chỉ (TC) nhỏ hơn so với số TC yêu cầu trong CTĐT, thì Học phần đó có được công nhận không? (Điều5)":
        [
            "Kết quả của học phần đó sẽ không được công nhận để thay thế cho học phần yêu cầu trong CTĐT.",
        ],

    // Câu 7 - Điều 17: chuyển vào CTĐT Tài năng
    "Sinh viên được phép đề nghị xét chuyển vào học các CTĐT Tài năng cùng ngành học khi kết thúc năm học thứ hai, nếu Điểm Trung bình Tích lũy (CPA) đạt từ loại nào trở lên? (Điều 17)":
        ["Từ loại Giỏi trở lên (CPA ≥ 3,2)."],

    // Câu 8 - Điều 3: cấu trúc năm học
    "Một năm học tại ĐHBK Hà Nội bao gồm những học kỳ nào?":
        ["Hai học kỳ chính và một học kỳ hè."],

    // Câu 9 - Điều 5: điểm liệt đồ án tốt nghiệp
    "Theo Quy chế Đào tạo, mức điểm nào được coi là điểm liệt đối với học phần đồ án tốt nghiệp/khóa luận tốt nghiệp cử nhân, đồ án tốt nghiệp kỹ sư? (Điều 5)":
        ["Điểm số dưới 5,0."],

    // Câu 10 - Học bổng KKHT loại Xuất sắc (A)
    "Học bổng Khuyến khích Học tập (KKHT) loại Xuất sắc (A) có mức hỗ trợ bằng bao nhiêu lần mức học bổng loại khá (C), và mức học bổng loại khá (C) được tính bằng gì?":
        [
            "Bằng 1,5 lần mức khá; mức khá bằng tổng học phí của tất cả các học phần tính điểm trung bình học kỳ (GPA).",
        ],

    // Câu 11 - Điều 4: học phần tiên quyết
    'Quy tắc nào sau đây mô tả đúng về "Học phần tiên quyết"? (Điều 4)':
        [
            "Sinh viên phải hoàn thành học phần A (với mức điểm đạt) mới được dự lớp học phần B.",
        ],

    // Câu 12 - Điều 4: điều kiện tương đương
    "Hai học phần được coi là tương đương khi có điều kiện nào về nội dung chuyên môn? (Điều 4)":
        ["Nội dung chuyên môn trùng lặp tối thiểu 70%."],

    // Câu 13 - Điều 10: giai đoạn đăng ký học phần
    "Theo Quy chế Đào tạo của ĐHBK HN, giai đoạn Đăng ký học phần (chọn các học phần dự tính sẽ học) cho một học kỳ tiếp theo được tổ chức vào thời điểm nào? Điều 10":
        ["Những tuần đầu của học kỳ trước đó."],

    // Câu 15 - Điều 14: điều kiện tốt nghiệp đại học
    "Điều kiện nào sau đây KHÔNG bắt buộc để sinh viên được xét công nhận tốt nghiệp đại học? (Điều 14)":
        ["Điểm trung bình tích lũy toàn khóa đạt từ loại Khá trở lên (CPA)."],

    // Câu 16 - Điều 5 mục 7a: điểm đạt thực tập/đồ án tốt nghiệp
    "Điểm \"Đạt\" của học phần Thực tập tốt nghiệp, Đồ án tốt nghiệp được quy định như thế nào (Theo Điều 5, mục 7, phần a, trong QCĐT2025)?(1 point)":
        ["Điểm KTHP phải từ C trở lên. (ĐCK, ĐQT ≥ 5)"],

    // Câu 17 - nghỉ học tạm thời do ốm/tai nạn/thai sản
    "Thời gian nghỉ học tạm thời của sinh viên đại học do ốm, tai nạn hoặc thai sản buộc phải điều trị dài ngày có được tính vào thời gian học chậm tiến độ không, và tối đa là bao nhiêu học kỳ chính?":
        [
            "Thời gian nghỉ không tính vào thời gian chậm tiến độ nếu tổng cộng không vượt quá 04 học kỳ chính. (Nếu thời gian nghỉ học này vượt quá 04 học kỳ chính, thì thời gian vượt quá đó sẽ được tính vào thời gian học chậm tiến độ)",
        ],

    // Câu 18 - Điều 22: ĐATN kỹ sư đạt từ điểm nào
    "Theo Quy chế Đào tạo, Đồ án Tốt nghiệp Kỹ sư (ĐATN KS) được đánh giá đạt khi điểm đánh giá học phần đạt từ mức điểm chữ nào trở lên? (Điều 22)":
        ["Từ điểm C trở lên."],

    // Câu 19 - hoãn thi, thời hạn thi bù
    "Sau khi hoãn thi vì lý do chính đáng, sinh viên phải dự thi bù trong thời hạn bao lâu để không bị nhận điểm F?":
        ["Trong vòng 2 học kỳ chính tiếp theo."],

    // Câu 20 - Điều 5: trọng số điểm cuối kỳ
    "Đối với học phần có khối lượng từ 2 Tín chỉ (TC) trở lên, điểm học phần được đánh giá từ những điểm thành phần nào và trọng số tối thiểu/tối đa của điểm cuối kỳ là bao nhiêu? (Điều 5)":
        [
            "Điểm quá trình và điểm cuối kỳ; trọng số điểm cuối kỳ nằm trong khoảng từ 0,5 đến 0,8.",
        ],

    // Câu 21 - Điều 3: học bổng loại Giỏi (B)
    "Để đạt Học bổng loại Giỏi (loại B), sinh viên cần đạt tiêu chuẩn nào? Điều 3":
        ["GPA ≥ 3,2 và điểm rèn luyện học kỳ ≥ 80 điểm."],

    // Câu 22 - cung cấp thông tin cho cha/mẹ SV
    "Công tác QLLSV có trách nhiệm cung cấp thông tin về kết quả học tập và rèn luyện cho cha/mẹ hoặc người giám hộ của sinh viên khi nào?":
        [
            "Khi có yêu cầu đối với các trường hợp sinh viên bị cảnh báo học tập, bị xử lý kỷ luật, bị đình chỉ học tập hoặc bị buộc thôi học.",
        ],

    // Câu 23 - lộ trình học song hành NNCB
    "Theo lộ trình học tập, sinh viên bắt đầu tự đăng ký học song hành các học phần NNCB cùng với các học phần khác trong CTĐT từ học kỳ nào trở đi?":
        ["Học kỳ 3"],

    // Câu 24 - Điều 19: nâng mức cảnh báo học tập
    "Theo quy định về Cảnh báo Học tập (Điều 19), việc nâng mức cảnh báo học tập đối với sinh viên được xác định dựa trên số Tín chỉ (TC) không đạt trong học kỳ như thế nào?":
        [
            "Nâng một mức cảnh báo nếu số TC không đạt trong học kỳ lớn hơn 8; Nâng hai mức cảnh báo nếu số TC không đạt trong học kỳ lớn hơn 16.",
        ],

    // Câu 25 - chứng chỉ không được công nhận
    "Trường hợp nào sau đây KHÔNG được công nhận sử dụng để xét quy đổi tương đương chứng chỉ và miễn học hoặc xét chuẩn đầu ra?":
        [
            "Chứng chỉ tiếng Anh TOEFL iBT theo hình thức Home Edition.",
        ],

    // Câu 26 - CTĐT chuẩn (tiếng Anh), điều kiện đăng ký HP từ HK3
    "Đối với CTĐT chuẩn (Tiếng Anh), điều kiện bắt buộc để sinh viên được đăng ký các học phần khác trong CTĐT kể từ Học kỳ 3 trở đi là gì?":
        [
            "Sinh viên phải đăng ký học song hành học phần FL1133 Tiếng Anh cơ sở 3 nếu chưa học hoặc chưa được miễn.",
        ],

    // Câu 27 - điều kiện tốt nghiệp CTĐT thứ hai
    "Sinh viên học cùng lúc hai chương trình chỉ được xét tốt nghiệp chương trình thứ hai nếu thỏa mãn điều kiện nào sau đây?":
        [
            "Có đủ điều kiện tốt nghiệp ở chương trình thứ nhất và đã đăng kí học CTĐT thứ hai muộn nhất 02 năm trước thời điểm xét tốt nghiệp. (Lưu ý: Sinh viên học cùng lúc hai CTĐT sẽ phải đăng ký tốt nghiệp cùng đợt cho cả hai CTĐT)",
        ],

    // Câu 28 - CVHT hướng dẫn truy cập ứng dụng
    "Cố vấn học tập có nhiệm vụ hướng dẫn sinh viên truy cập vào các ứng dụng nào để tiếp cận thông tin về chương trình, lịch trình học tập chuẩn, các quy chế, quy định?":
        ["eHUST, Cổng thông tin."],

    // Câu 29 - Điều 4: thứ tự ưu tiên xét học bổng
    "Thứ tự ưu tiên xét cấp học bổng khi quỹ học bổng có giới hạn được thực hiện như thế nào? Điều 4":
        [
            "Từ loại A đến loại C, từ điểm GPA cao cho đến điểm GPA thấp.",
        ],

    // Câu 30 - hậu quả đăng ký không phù hợp
    "Đăng ký học tập không phù hợp có thể dẫn đến hậu quả như thế nào?":
        [
            "Số tín chỉ nợ (nếu có) tăng dần chứ không giảm; Chậm tiến độ; Kết quả học tập kém",
        ],

    // Câu 31 - Khoản 3 Điều 4: KHÔNG được xét học bổng KKHT
    "Sinh viên thuộc trường hợp nào sau đây KHÔNG được xét cấp học bổng KKHT? Khoản 3, Điều 4.":
        [
            "Học quá thời gian theo kế hoạch học tập chuẩn. Đang chịu hình thức kỷ luật từ mức khiển trách trở lên.",
        ],

    // Câu 32 - Điều 10: quy trình đăng ký học tập
    "Quy trình Đăng ký Học tập (học kỳ chính) đối với sinh viên đại học tại ĐHBK Hà Nội bao gồm những giai đoạn nào và thời gian điều chỉnh đăng ký được quy định như thế nào? (Điều 10)":
        [
            "Gồm 3 giai đoạn: Đăng ký học phần, Đăng ký lớp chính thức, và Điều chỉnh đăng ký; mỗi học kỳ chính có hai đợt điều chỉnh đăng ký, kết thúc trước khi bắt đầu học kỳ.",
        ],

    // Câu 33 - Điều 5: điểm chữ cho học phần miễn học công nhận TC
    "Trong các điểm chữ đặc biệt sau, điểm chữ nào được sử dụng để chỉ kết quả học phần đã được miễn học và công nhận Tín chỉ (TC)? (Điều 5)":
        ["Điểm R."],

    // Câu 34 - Thời gian và TC tối thiểu CTĐT Cử nhân
    "Thời gian và Khối lượng Tín chỉ Tối thiểu của Chương trình đào tạo Cử nhân được quy định thế nào?":
        ["Thời gian 4 năm, với khối lượng tối thiểu là 132 tín chỉ."],

    // Câu 35 - Cảnh báo học tập mức 3
    "Cảnh báo học tập mức 3 khi nào":
        [
            "Số tín chỉ không đạt tích lũy >24 tín chỉ tính từ đầu khóa",
        ],

    // Câu 36 - xuyên tạc nhà giáo trên mạng xã hội
    "Sinh viên sử dụng mạng xã hội để xuyên tạc, nói xấu nhà giáo và cán bộ trường sẽ bị xử lý như thế nào?":
        [
            "Nghiêm cấm thực hiện và bị xử lý kỷ luật nặng.",
        ],

    // Câu 37 - Điều 10: điều kiện mở lớp học phần rút gọn
    "Để xem xét mở lớp học phần rút gọn (theo nguyện vọng của sinh viên), sinh viên cần thỏa mãn đồng thời những điều kiện nào sau đây? (Điều 10)":
        [
            "Sinh viên đã học học phần đó ít nhất 02 lần nhưng chưa đạt; Điểm quá trình của học phần phải từ 2 điểm trở lên trong lần học gần nhất; Sinh viên đạt trình độ năm học từ năm thứ ba trở lên.",
        ],

    // Câu 38 - học lại học phần đã đạt để cải thiện CPA
    "Khi người học đăng ký học lại một học phần đã có điểm đạt để cải thiện Điểm Trung bình Tích lũy (CPA), kết quả điểm nào sẽ được công nhận là điểm chính thức của học phần đó?":
        [
            "Điểm lần cao nhất được công nhận là điểm chính thức của học phần.",
        ],

    // Câu 39 - không nộp đủ học phí
    "Theo Quy chế Đào tạo, nếu người học không nộp đủ học phí sau thời gian quy định thì sẽ bị xử lý như thế nào?":
        ["Bị đình chỉ đăng ký học tập một học kỳ kế tiếp."],

    // Câu 40 - ký hiệu miễn học NNCB và thời hạn
    "Kết quả miễn học các học phần Ngoại ngữ cơ bản được ghi bằng ký hiệu gì trong dữ liệu học tập và có giá trị trong bao lâu?":
        ["Ký hiệu \"R\" và có giá trị toàn khóa"],

    // Câu 41 - khi gặp khó khăn áp lực học tập
    "SVBK HN Khi Gặp khó khăn, áp lực trong học tập, bạn CẦN chia sẻ và tìm đến đâu trước tiên?":
        [
            "Giáo viên chủ nhiệm lớp, cố vấn học tập Trường/Khoa bạn đang theo học (hay bất cứ người thân trong GĐ (bạn bè) nào mà bạn có thể chia sẻ).",
        ],

    // Câu 42 - Điều 2: đối tượng áp dụng học bổng KKHT
    "Đối tượng áp dụng của Quy định xét cấp học bổng khuyến khích học tập tại Đại học Bách khoa Hà Nội là sinh viên thuộc hình thức đào tạo nào? Điều 2":
        [
            "Sinh viên đại học hình thức đào tạo chính quy văn bằng thứ nhất.",
        ],

    // Câu 43 - Điều 12: xếp loại học lực Giỏi
    'Mức xếp loại học lực "Giỏi" được quy định căn cứ trên Điểm Trung bình Tích lũy (CPA) hoặc Điểm Trung bình Học kỳ (GPA) là bao nhiêu? (Điều 12)':
        ["CPA hoặc GPA từ 3,2 đến 3,59."],

    // Câu 44 - thời gian được phép học CTĐT cử nhân
    "Thời gian được phép học tại ĐHBK Hà Nội đối với CTĐT đại học (Cử nhân) hình thức chính quy theo kế hoạch học tập chuẩn (4 năm), và sinh viên được phép tốt nghiệp chậm tối đa bao nhiêu học kỳ chính?":
        ["4 Năm, Thời gian chậm tiến độ tối đa không được vượt quá 5 học kỳ chính"],

    // Câu 45 - hệ thống CVHT và QLLSV truy cập
    "Cán bộ CVHT và QLLSV đều được cấp quyền truy cập vào hệ thống quản lý thông tin nào?":
        [
            "Hệ thống quản lý thông tin quá trình học tập và rèn luyện của sinh viên.",
        ],

    // Câu 46 - hạn chế đăng ký khi bị CBHT M2, M3
    "Sinh viên đang bị cảnh báo học tập từ M2, M3 thì bị hạn chế đăng ký học tập như thế nào?":
        ["Được đăng ký tối thiểu là 8 tín chỉ, tối đa là 14 tín chỉ"],

    // Câu 47 - Điều 4 mục 6: học phần song hành
    "Học phần A là học phần song hành của học phần B nghĩa là: theo điều 4 mục 6 QCĐT2025":
        [
            "Sinh viên phải theo học trước hoặc học đồng thời học phần A với học phần B",
        ],

    // Câu 48 - điểm liệt học phần thông thường
    "Điểm liệt của một học phần thông thường được quy định như thế nào?":
        ["Điểm thành phần (điểm quá trình, điểm thi cuối kỳ)<3"],

    // Câu 49 - tiêu chuẩn rèn luyện để hỗ trợ CVHT
    "Theo Quy định, sinh viên đại học muốn tham gia hỗ trợ công tác CVHT cần đáp ứng tiêu chuẩn nào về kết quả rèn luyện?":
        [
            "Kết quả rèn luyện từ loại Giỏi trở lên. có trình độ từ năm thứ 3 trở đi, được Cố vấn học tập lựa chọn, đề xuất và được Trưởng đơn vị quản ngành (Trường/Khoa) phê duyệt.",
        ],

    // Câu 50 - Điều 4: học phần bắt buộc vs tự chọn theo mô đun
    "Sự khác biệt chính giữa \"Học phần bắt buộc\" và \"Học phần tự chọn theo mô đun\" là gì? (Điều 4)":
        [
            "Học phần bắt buộc yêu cầu hoàn thành TẤT CẢ học phần trong danh mục; Học phần tự chọn theo mô đun yêu cầu chọn một định hướng và hoàn thành TẤT CẢ học phần trong danh mục của nhóm học phần tự chọn theo mô đun đó.",
        ],

    // Câu 51 - yêu cầu kỹ năng chứng chỉ ngoại ngữ đầu ra
    "Yêu cầu về kỹ năng đối với chứng chỉ tiếng Anh được sử dụng để xét chuẩn ngoại ngữ đầu ra là gì?":
        ["Phải đánh giá đầy đủ 4 kỹ năng nghe, nói, đọc, viết."],

    // Câu 52 - sau khi học xong HP tương đương/thay thế
    "Khi đăng ký học một học phần tương đương/thay thế thì cần phải làm gì sau khi học xong ?":
        [
            "Viết email xin chuyển điểm tương đương/thay thế ngay sau khi điểm học phần đó có điểm đạt ở trong bảng kết quả học tập",
        ],

    // Câu 53 - giới hạn công nhận chuyển đổi TC từ nơi khác
    "Khối lượng tối đa được công nhận, chuyển đổi Tín chỉ (TC) từ một trình độ đào tạo khác, một CTĐT khác hoặc từ một cơ sở đào tạo khác không được vượt quá bao nhiêu phần trăm (%) khối lượng chương trình học tập toàn khóa?":
        ["Không vượt quá 50%."],

    // Câu 54 - tụ tập khu vực công cộng sau 18h
    "Hành vi tụ tập tại các khu vực công cộng trong trường sau 18h00 mà không được phép sẽ bị xử lý thế nào?":
        ["Bị kỷ luật từ mức Cảnh cáo đến Buộc thôi học."],

    // Câu 56 - số TC tối thiểu để được xét học bổng
    "Trừ học kỳ 1 năm học thứ nhất, sinh viên sẽ không được xét cấp học bổng nếu đăng ký học ít hơn bao nhiêu tín chỉ (kể cả các học phần không tính điểm GPA) tại học kỳ lấy điểm xét, cấp học bổng?":
        ["Ít hơn 15 tín chỉ."],

    // Câu 57 - giảm một mức hạng tốt nghiệp
    "Sinh viên có điểm trung bình toàn khóa xếp loại Giỏi trở lên (CPA) sẽ bị giảm một mức hạng tốt nghiệp nếu xảy ra trường hợp nào sau đây?":
        [
            "Khối lượng của các học phần phải học lại vượt quá 5% tổng số TC của các học phần được dùng tính điểm trung bình toàn khóa.",
        ],

    // Câu 58 - ghi âm ghi hình trong giờ học
    "Hành vi ghi âm, ghi hình trong giờ học khi chưa được sự đồng ý của giảng viên là vi phạm quy tắc gì?":
        ["Bộ Quy tắc ứng xử văn hóa sinh viên"],

    // Câu 59 - khối lượng TC tối thiểu Cử nhân và Thạc sĩ
    "Khối lượng học tập tối thiểu (số tín chỉ - TC) đối với Chương trình Cử nhân (tốt nghiệp THPT) và Chương trình Thạc sĩ (tốt nghiệp cử nhân) lần lượt là bao nhiêu?":
        ["Cử nhân: 132 TC; Thạc sĩ: 60 TC."],

    // Câu 60 - Điều 9: rút học phần trong 7 tuần đầu và học phí
    "Đối với sinh viên thuộc CTĐT cử nhân, kỹ sư có đơn đề nghị rút học phần trong khoảng thời gian 7 tuần đầu của học kỳ, nếu được giải quyết theo nguyện vọng thì học phí của học phần đó được quy định như thế nào? (Điều 9)":
        ["Chỉ đóng một nửa (50%) học phí của học phần đó."],

    // Câu 61 - Điều 2; Điều 4: học bổng loại Khá (C)
    "Tiêu chuẩn tối thiểu để sinh viên đạt Học bổng loại Khá (loại C) là gì? Điều 2; Điều 4":
        ["GPA ≥ 2,5 và điểm rèn luyện học kỳ ≥ 65 điểm."],

    // Câu 62 - Điều 10: đăng ký TC tối đa/tối thiểu không bị CBHT
    "Sinh viên đại học KHÔNG thuộc diện CẢNH BÁO học tập được phép đăng ký khối lượng tối đa và tối thiểu bao nhiêu Tín chỉ (TC) trong một học kỳ chính? (Điều 10)":
        ["Tối đa 24 TC và tối thiểu 12 TC."],

    // Câu 63 - phương pháp quản lý chi tiêu 50-20-30
    "Phương pháp quản lý chi tiêu 50-20-30 với sinh viên?":
        [
            "50% Nhu cầu thiết yếu, 20% Tiết kiệm, 30% Sở thích cá nhân",
        ],

    // Câu 64 - Điều 4: học phần song hành nghĩa là gì
    "Theo Quy chế Đào tạo 2025 của Đại học Bách khoa Hà Nội, quy định \"Học phần A là học phần song hành của học phần B\" có nghĩa là gì?":
        [
            "Sinh viên phải theo học học phần A trước hoặc học đồng thời (cùng lúc) với học phần B.",
        ],

    // Câu 65 - Điều 12: xếp hạng "Năm thứ ba"
    "Theo Quy chế Đào tạo, sinh viên được xếp hạng trình độ năm học căn cứ vào số Tín chỉ Tích lũy (TCTL). Sinh viên được xếp trình độ \"Năm thứ ba\" khi có số TCTL nằm trong khoảng nào? (Điều 12)":
        ["Số TCTL từ 64 - 95."],

    // Câu 66 - Điều 4 mục 6: học phần học trước
    "Học phần A là học phần học trước của học phần B nghĩa là ? theo điều 4 mục 6 QCĐT2025":
        [
            "Sinh viên phải đăng ký và học xong (có thể chưa đạt) học phần A mới được dự lớp học phần B",
        ],

    // Câu 67 - Điều 2: áp dụng phiên bản CTĐT
    "Sinh viên, học viên nhập học năm nào sẽ được áp dụng phiên bản chương trình giảng dạy của năm đó, ngoại trừ trường hợp nào? (Điều 2) ?":
        [
            "Những cập nhật liên quan đến Chương trình Đào tạo không được ảnh hưởng đến kết quả học tập, rèn luyện đã tích lũy của người học.",
        ],

    // Câu 68 - hoãn thi và thi bù trong bao lâu
    "Người học không thể dự thi cuối kỳ một học phần (đã học và đã đóng học phí) do ốm, tai nạn hoặc lý do chính đáng được phép hoãn thi và được dự thi cuối kỳ học phần đó trong thời hạn bao lâu để hoàn thiện điểm?":
        ["Trong thời hạn 2 học kỳ chính tiếp theo."],

    // Câu 69 - mượn thẻ sinh viên
    "Sinh viên mượn thẻ hoặc cho người khác mượn thẻ sinh viên để sử dụng sẽ bị xử lý như thế nào?":
        ["Bị xử lý kỷ luật theo quy định của Nhà trường."],

    // Câu 70 - tăng một mức cảnh báo học tập
    "Khi nào thì tăng một mức cảnh báo học tập":
        ["Khi số tín chỉ không đạt trong một học kỳ chính>8"],

    // Câu 71 - thời hạn chứng chỉ ngoại ngữ đầu ra
    "Chứng chỉ tiếng Anh dùng để xét chuẩn ngoại ngữ đầu ra phải đáp ứng điều kiện về thời hạn nào?":
        [
            "Phải được cấp trong vòng 2 năm tính đến thời điểm xét chuẩn ngoại ngữ đầu ra và còn hiệu lực tại thời điểm xét.",
        ],

    // Câu 72 - Khoản 3 Điều 4: kỷ luật KHÔNG được xét học bổng
    "Sinh viên sẽ KHÔNG được xét cấp học bổng khuyến khích học tập nếu tại thời điểm xét học bổng, họ chịu hình thức kỷ luật từ mức nào trở lên? Khoản 3, Điều 4":
        ["Từ mức khiển trách trở lên."],

    // Câu 73 - điều kiện kỷ luật nhận học bổng Trần Đại Nghĩa
    "Để nhận Học bổng Trần Đại Nghĩa, sinh viên phải đạt điều kiện kỷ luật nào?":
        [
            "Không đang trong thời gian bị kỷ luật từ mức Cảnh cáo trở lên.",
        ],

    // Câu 74 - rút học phần sau tuần 7 và học phí
    "Sinh viên nộp đơn xin rút học phần sau tuần thứ 7 của học kỳ chính sẽ phải xử lý học phí thế nào?":
        ["Phải đóng 100% học phí môn đó."],

    // Câu 76 - phân loại trình độ ngoại ngữ đầu vào
    "Căn cứ phân loại trình độ ngoại ngữ đầu vào với sinh viên CTĐT có chuẩn đầu ra là tiếng Anh bao gồm những tiêu chí nào?":
        [
            "Dựa trên một hoặc nhiều tiêu chí trong đó là: Kết quả kiểm tra tiếng Anh đầu khóa do ĐHBK Hà Nội tổ chức. Chứng chỉ tiếng Anh quốc gia/quốc tế.",
        ],

    // Câu 77 - Điều 5: quy đổi điểm 8,2 sang thang 4
    "Theo quy tắc quy đổi điểm học phần (Điều 5), nếu một sinh viên đạt Điểm học phần theo thang 10 là 8,2, thì Điểm chữ và Điểm số quy đổi tương ứng theo thang 4 là gì?":
        ["Điểm chữ: B+; Điểm số quy đổi: 3,5."],

    // Câu 78 - bị xếp loại rèn luyện Yếu/Kém 2 HK liên tiếp
    "Nếu sinh viên bị xếp loại rèn luyện Yếu/Kém trong hai học kỳ liên tiếp, kết quả học tập sẽ bị ảnh hưởng như thế nào?":
        [
            "Bị hạn chế đăng ký học tập tương đương cảnh báo học tập mức 2.",
        ],

    // Câu 79 - Điều 18: điều kiện duy trì khi học CTĐT thứ hai
    "Trong suốt thời gian học Chương trình đào tạo thứ hai, sinh viên cần duy trì những điều kiện nào để không bị loại khỏi danh sách đăng ký học chương trình thứ hai? (Điều 18)":
        [
            "Luôn đảm bảo khối lượng học tập ngành thứ nhất theo quy định với điểm CPA từ trung bình trở lên và không nằm trong diện bị cảnh báo học tập.",
        ],

    // Câu 81 - giảm một mức cảnh báo học tập
    "Giảm một mức cảnh báo học tập diễn ra khi nào":
        ["Nếu số tín chỉ không đạt trong một học kỳ <=4"],

    // Câu 82 - Điều 12: công thức quy đổi CPA loại Giỏi sang thang 10
    "Theo Quy chế Đào tạo, nếu Điểm Trung bình Tích lũy (CPA) của sinh viên nằm trong dải từ 3,2 đến cận 3,6 (loại Giỏi), công thức quy đổi tương đương sang thang điểm 10 là gì? (Điều 12)":
        ["Điểm thang 10 = CPA × 2,50 + 0,00."],

    // Câu 83 - trách nhiệm SV trong đánh giá rèn luyện
    "Trách nhiệm của sinh viên trong quy trình đánh giá kết quả rèn luyện là gì?":
        [
            "Tự lựa chọn tham gia hoạt động phù hợp, cung cấp minh chứng tham gia hoạt động và sử dụng minh chứng được xác nhận để tự đánh giá kết quả rèn luyện của bản thân.",
        ],

    // Câu 84 - nhiệm vụ CVHT ngoài hướng dẫn quy chế
    "Cố vấn học tập (CVHT) có nhiệm vụ chính nào ngoài việc hướng dẫn về quy chế đào tạo?":
        [
            "Tư vấn, hỗ trợ sinh viên xây dựng kế hoạch và phương pháp học tập phù hợp với mục tiêu và năng lực cá nhân.",
        ],

    // Câu 85 - thời hạn nộp đơn xin miễn NNCB
    "Thời gian tiếp nhận đơn đề nghị xét miễn học phần Ngoại ngữ cơ bản muộn nhất là bao lâu trước khi bắt đầu học kỳ theo Khung kế hoạch năm học?":
        ["2 tuần (trước khi bắt đầu học kỳ…)"],

    // Câu 86 - Điều 17 khoản 5b: học phần yêu cầu không còn giảng dạy
    "Theo điều 17 khoản 5b Quy chế đào tạo 2025, khi học phần yêu cầu không còn giảng dạy, sinh viên được:":
        ["Chuyển sang học phần thay thế"],

    // Câu 87 - Điều 4: 1 TC tương đương bao nhiêu giờ
    "Một Tín chỉ (TC) được tính tương đương bao nhiêu giờ học tập định mức của người học, bao gồm cả giờ giảng, tự học, nghiên cứu và đánh giá? (Điều 4)":
        ["50 giờ."],

    // Câu 88 - học phần NNCB thuộc khối kiến thức nào
    "Các học phần Ngoại ngữ cơ bản của các CTĐT được xếp vào khối kiến thức nào?":
        [
            "Khối kiến thức ngoại ngữ bổ trợ tăng cường và không tính tín chỉ trong CTĐT chính khóa.",
        ],

    // Câu 89 - hướng dẫn/phản biện cho ĐATN dưới 5
    "Nếu người hướng dẫn hoặc người phản biện cho điểm Đồ án tốt nghiệp dưới 5, sinh viên sẽ bị xử lý ra sao?":
        ["Không được phép tham gia bảo vệ ĐATN."],

    // Câu 90 - QLLSV và trách nhiệm với phụ huynh
    "Đối với các trường hợp sinh viên bị cảnh báo học tập, bị xử lý kỷ luật, bị đình chỉ học tập hoặc bị buộc thôi học, cán bộ Quản lý lớp sinh viên (QLLSV) có trách nhiệm gì liên quan đến phụ huynh khi có yêu cầu?":
        [
            "Kịp thời cung cấp thông tin về kết quả học tập và rèn luyện cho cha/mẹ hoặc người giám hộ của sinh viên khi có yêu cầu.",
        ],

    // Câu 91 - Điều 19: hạn chế TC khi bị CBHT M2 trở lên (HK1 CTĐT chuẩn)
    "Sinh viên đang bị cảnh báo học tập từ mức 2 trở lên sẽ bị hạn chế khối lượng đăng ký Tín chỉ (TC) trong học kỳ 1 của năm học như thế nào đối với Chương trình Đào tạo (CTĐT) chuẩn? (Điều 19)":
        ["Được đăng ký tối đa 14 TC và tối thiểu 8 TC."],

    // Câu 92 - khi trượt môn thì đăng ký lại khi nào
    "Khi một môn học bị trượt thì cần đăng ký khi nào ?":
        [
            "Đăng ký ngay trong học kỳ tiếp theo nếu môn học đó được mở",
        ],

    // Câu 93 - chuẩn đầu ra ngoại ngữ khi tốt nghiệp CTĐT chuẩn
    "Chuẩn đầu ra khi xét tốt nghiệp đối với Chương trình đào tạo chuẩn (trừ các CTĐT nhóm ngành ngôn ngữ) yêu cầu đạt chứng chỉ trình độ tối thiểu nào?":
        ["Bậc 3 (B1) (theo Bảng 2.1 của Phụ lục II)"],

    // Câu 94 - Điều 4: nhóm học phần tự chọn theo mô đun
    "Đối với \"Nhóm học phần tự chọn theo mô đun\", yêu cầu đối với người học là gì? (Điều 4)":
        [
            "Chọn một định hướng chuyên môn và phải hoàn thành tất cả học phần trong danh mục của nhóm học phần tự chọn theo mô đun đó.",
        ],

    // Câu 95 - tuần công bố danh sách học bổng
    "Danh sách sinh viên được cấp học bổng và mức điểm chuẩn để đạt học bổng được công bố trên cổng thông tin sinh viên chậm nhất vào tuần học thứ mấy của học kỳ cấp học bổng?":
        ["Tuần học thứ 10."],

    // Câu 96 - Điều 2: căn cứ xét học bổng theo học kỳ nào
    "Học bổng khuyến khích học tập được cấp cho sinh viên căn cứ vào thành tích học tập và rèn luyện trong thời gian nào? Điều 2":
        ["Học kỳ chính liền trước đó."],

    // Câu 97 - điều kiện chuyển sang CTĐT khác sau năm 1
    "Sinh viên học hết năm học thứ nhất được xem xét chuyển sang học một CTĐT khác (cùng trình độ) nếu đáp ứng các điều kiện nào sau đây?":
        [
            "Xếp loại học lực căn cứ theo CPA đạt từ loại Khá trở lên (CPA ≥ 2,5), không bị cảnh báo học tập, và hiện đang không bị kỷ luật.",
        ],

    // Câu 98 - Điều 16: xử lý HP đã đăng ký khi nghỉ tạm thời
    "Khi chế độ nghỉ tạm thời (trừ trường hợp được điều động vào lực lượng vũ trang hoặc đi làm nghĩa vụ quốc tế) có hiệu lực, các học phần đã đăng ký học trong học kỳ đó sẽ bị xử lý như thế nào? (Điều 16)":
        [
            "Các học phần đã đăng ký học trong học kỳ sẽ bị hủy và tính học phí theo quy định tại khoản 4 Điều 9 Quy chế Đào tạo ĐHBK HN.",
        ],

    // Câu 99 - CPA để đạt hạng tốt nghiệp Xuất sắc
    "Để đạt được Hạng Tốt nghiệp Xuất sắc (hoặc xếp loại học lực Xuất sắc), Điểm Trung bình Tích lũy (CPA) của sinh viên phải nằm trong dải điểm nào theo thang 4?":
        ["GPA hoặc CPA được xếp đạt từ 3,6 đến 4,0."],

    // Câu 100 - Điều 18: điều kiện đăng ký học CTĐT thứ hai
    "Tại thời điểm đăng ký học cùng lúc chương trình thứ hai (Điều 18), sinh viên phải có học lực tính theo Điểm Trung bình Tích lũy (CPA) xếp loại như thế nào?  Các điều kiện khác kèm theo?":
        [
            "Xếp loại Trung bình trở lên (CPA từ 2.0). Thuộc hình thức đào tạo chính quy. Được phép đăng ký sớm nhất khi đã được xếp trình độ năm thứ hai của chương trình thứ nhất. Đáp ứng điều kiện trúng tuyển của chương trình thứ hai trong năm tuyển sinh. Luôn đảm bảo khối lượng học tập ngành thứ nhất theo quy định với điểm CPA từ trung bình trở lên và không nằm trong diện bị cảnh báo học tập",
        ],

    // Câu 101 - Điều 19: KHÔNG bị buộc thôi học
    "Trường hợp nào sau đây sinh viên KHÔNG bị xét Buộc thôi học theo Quy chế Đào tạo? (Điều 19)":
        ["Sinh viên bị cảnh báo học tập mức 3 lần thứ nhất."],

    // Câu 102 - Điều 7: thang điểm và làm tròn CPA/GPA
    "Điểm Trung bình Tích lũy (CPA) và Điểm Trung bình Học kỳ (GPA) được tính dựa trên thang điểm nào và được làm tròn tới bao nhiêu chữ số thập phân? (Điều 7)":
        ["Tính theo thang 4; làm tròn tới 2 chữ số thập phân."],

    // Câu 103 - Điều 21: đăng ký trước HP chương trình kỹ sư tối đa bao nhiêu TC
    "Trong quá trình học tập ở bậc đào tạo cử nhân, học viên được đăng ký học trước tối đa bao nhiêu Tín chỉ (TC) các học phần thuộc Chương trình Đào tạo kỹ sư? (Điều 21)":
        ["Tối đa 15 TC."],

    // Câu 104 - lập kế hoạch toàn khóa cần nắm vững thông tin gì
    "Lập kế hoạch toàn khóa cần nắm vững Chương trình đào tạo gồm các thông tin?":
        ["Cả ba phương án trên"],
};

const totalQuestions = Object.keys(answers).length;
console.log(`Tổng số câu hỏi: ${totalQuestions}`);

async function autoFillFormBasedOnQuestion() {
    // Xử lý Textarea đảm bảo React nhận diện được giá trị
    const inputExep = document.querySelector('textarea[placeholder="Nhập câu trả lời của bạn"], textarea[placeholder="Enter your answer"]');
    if (inputExep) {
        const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
        nativeInputValueSetter.call(inputExep, "Thượng tôn pháp luật là việc coi pháp luật là chuẩn mực cao nhất trong xã hội, mọi người đều bình đẳng và phải tuân thủ pháp luật, không ai được đứng trên pháp luật. Là sinh viên, để trở thành công dân tốt, chúng ta cần học tập, rèn luyện ý thức chấp hành pháp luật, tôn trọng quyền và lợi ích hợp pháp của người khác, sống trung thực, có trách nhiệm, tích cực tham gia các hoạt động vì cộng đồng và góp phần xây dựng một xã hội văn minh, công bằng, kỷ cương.");
        // Kích hoạt event để React cập nhật state
        inputExep.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
        console.error("Không tìm thấy ô nhập liệu!");
    }

    // Hàm chuẩn hóa text: đổi ngoặc cong thành thẳng, xóa khoảng trắng thừa, đưa về chữ thường
    const normalizeText = (text) => {
        if (!text) return "";
        return text
            .replace(/[“”]/g, '"') // Xử lý ngoặc kép cong
            .replace(/[‘’]/g, "'") // Xử lý ngoặc đơn cong
            .replace(/\s+/g, " ")  // Rút gọn khoảng trắng
            .trim()
            .toLowerCase();        // Đưa về chữ thường để bỏ qua lỗi viết hoa/thường
    };

    const spans = document.querySelectorAll(".text-format-content");

    spans.forEach((span) => {
        // 1. Lấy và chuẩn hóa câu hỏi trên form, cắt bỏ số thứ tự (VD: "37. ") và dấu "*"
        let formQuestion = span.innerText.replace(/^\d+\.\s*/, '').replace(/\*$/, '');
        let normalFormQuestion = normalizeText(formQuestion);

        // 2. Tìm key tương ứng trong object answers (chấp nhận khớp 1 phần)
        const matchedKey = Object.keys(answers).find(key => {
            let normalKey = normalizeText(key);
            // Kiểm tra 2 chiều: Form chứa Key hoặc Key chứa Form
            return normalFormQuestion.includes(normalKey) || normalKey.includes(normalFormQuestion);
        });

        if (matchedKey) {
            const answersList = Array.isArray(answers[matchedKey]) ? answers[matchedKey] : [answers[matchedKey]];
            const parrentDiv = span.closest('div[data-automation-id="questionItem"]');
            
            if (!parrentDiv) return;

            // Lấy tất cả các ô radio/checkbox trong câu hỏi hiện tại
            const optionInputs = parrentDiv.querySelectorAll('input[type="radio"], input[type="checkbox"]');

            answersList.forEach((ans) => {
                let normalAns = normalizeText(ans); // Chuẩn hóa đáp án mẫu trong code

                optionInputs.forEach((input) => {
                    let normalInputValue = normalizeText(input.value); // Chuẩn hóa đáp án thực tế trên form

                    // 3. So sánh: Đáp án trên form (đã bỏ "A. ") có chứa đáp án mẫu hay không
                    if (!input.checked && normalInputValue.includes(normalAns)) {
                        input.click();
                        input.dispatchEvent(new Event('change', { bubbles: true }));
                        console.log(`Đã tự động điền câu: "${matchedKey}"`);
                    }
                });
            });
        }
    });
}

// Lắng nghe tín hiệu từ popup.js
chrome.runtime.onMessage.addListener(async (message) => {
    if (message.action === "fillForm") {

        try {
            await autoFillFormBasedOnQuestion();
            alert("Filled success!!");
        } catch (error) {
            console.error("Error filling the form:", error);
        }
    }
});
